#ifndef PRIMITIVE_HPP
#define PRIMITIVE_HPP

// Ponto único de verdade para a enumeração de tipos primitivos.
enum class Primitive {
    INT, FLOAT, CHAR, BOOL, VOID
};

#endif // PRIMITIVE_HPP