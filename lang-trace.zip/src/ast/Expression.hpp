#ifndef EXPRESSION_HPP
#define EXPRESSION_HPP
#include "Node.hpp"
class Expression : public Node {};
#endif