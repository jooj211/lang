#ifndef COMMAND_HPP
#define COMMAND_HPP
#include "Node.hpp"
class Command : public Node {};
#endif