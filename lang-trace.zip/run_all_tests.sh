#!/bin/bash

# Executa todos os .lan em ./instances sem abortar no primeiro erro.
# Gera logs por arquivo em ./logs e mostra um resumo final.

set -u

# --- Configuração ---
COMPILER_EXEC="./build/lang"
TEST_DIR="./instances"
LOG_DIR="./logs"

# --- Verificações ---
if [ ! -x "$COMPILER_EXEC" ]; then
  echo "Erro: compilador não encontrado/executável em '$COMPILER_EXEC'."
  echo "Compile primeiro (ex.: cmake .. && make -j dentro de build/)."
  exit 1
fi
if [ ! -d "$TEST_DIR" ]; then
  echo "Erro: diretório de testes não encontrado: '$TEST_DIR'."
  exit 1
fi

mkdir -p "$LOG_DIR"

echo "============================================================"
echo "Executando testes em: $TEST_DIR"
echo "Binário: $COMPILER_EXEC"
echo "Logs em: $LOG_DIR"
echo "============================================================"

total=0
ok=0
fail=0
failed_list=()

# Itera de forma segura (suporta nomes com espaços)
while IFS= read -r -d '' test_file; do
  total=$((total+1))
  base="$(basename "${test_file%.lan}")"
  out="$LOG_DIR/${base}.log"

  echo "--- Executando: $test_file ---"
  if "$COMPILER_EXEC" --debug -i "$test_file" >"$out" 2>&1; then
    echo "[OK] $test_file"
    ok=$((ok+1))
  else
    echo "[ERRO] $test_file (veja: $out)"
    fail=$((fail+1))
    failed_list+=("$test_file")
  fi
  echo
done < <(find "$TEST_DIR" -type f -name "*.lan" -print0 | sort -z)

echo "============================================================"
echo "Resumo: $ok OK / $fail falhas / $total total"
if [ "$fail" -gt 0 ]; then
  echo "Falharam:"
  for f in "${failed_list[@]}"; do echo " - $f"; done
  exit 1
fi
echo "Todos os testes passaram."
